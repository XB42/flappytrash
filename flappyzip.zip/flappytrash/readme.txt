************************************************* TO RUN ****************************************************

open index.html in a browser

Computer must have some browser installed
**************************************************Controls***************************************************

Space bar to move the truck up

Collect as many garbage bags as you can by touching the front end of the truck to it

Dont hit the pipes or fall in the trash

Collect at least 10 bags to successfully clean up or be trashed

*************************************************************************************************************